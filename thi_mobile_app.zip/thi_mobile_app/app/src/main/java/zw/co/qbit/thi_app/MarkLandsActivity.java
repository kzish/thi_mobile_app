package zw.co.qbit.thi_app;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MarkLandsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mark_lands);
    }
}
